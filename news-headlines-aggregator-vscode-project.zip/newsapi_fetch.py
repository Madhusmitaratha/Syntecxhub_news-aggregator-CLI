
import requests

API_KEY = "YOUR_NEWSAPI_KEY"

def fetch_newsapi(keyword=None):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": keyword if keyword else "news",
        "language": "en",
        "apiKey": API_KEY
    }

    response = requests.get(url, params=params)
    data = response.json()

    articles = []
    for item in data.get("articles", []):
        articles.append({
            "title": item["title"],
            "source": item["source"]["name"],
            "date": item["publishedAt"],
            "url": item["url"]
        })
    return articles
