
# News Headlines Aggregator

Python CLI project that collects news headlines from multiple sources using NewsAPI and web scraping.

## Features
- Fetch news using NewsAPI
- Scrape BBC headlines
- CLI filters (source, keyword, date)
- Store results in SQLite
- Export to CSV and Excel

## Install

pip install -r requirements.txt

## Run

python main.py

Keyword filter:

python main.py --keyword AI

Source filter:

python main.py --source BBC

Export CSV:

python main.py --export csv
