
import requests
from bs4 import BeautifulSoup

def scrape_bbc():
    url = "https://www.bbc.com/news"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    headlines = []
    for h in soup.select("h3")[:15]:
        headlines.append({
            "title": h.get_text(strip=True),
            "source": "BBC",
            "date": "",
            "url": url
        })

    return headlines
