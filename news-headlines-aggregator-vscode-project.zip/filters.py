
def filter_news(news_list, source=None, keyword=None, date=None):
    filtered = []

    for item in news_list:
        if source and source.lower() not in item["source"].lower():
            continue
        if keyword and keyword.lower() not in item["title"].lower():
            continue
        if date and date not in item["date"]:
            continue

        filtered.append(item)

    return filtered
