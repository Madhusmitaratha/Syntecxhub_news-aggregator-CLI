
import sqlite3
import pandas as pd

DB_NAME = "news.db"

def export_csv():
    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM news", conn)
    df.to_csv("news_export.csv", index=False)
    print("CSV exported successfully")

def export_excel():
    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM news", conn)
    df.to_excel("news_export.xlsx", index=False)
    print("Excel exported successfully")
