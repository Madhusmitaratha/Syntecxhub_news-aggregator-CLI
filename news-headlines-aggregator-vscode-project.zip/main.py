
import argparse
from newsapi_fetch import fetch_newsapi
from scraper import scrape_bbc
from database import init_db, insert_news
from filters import filter_news
from export import export_csv, export_excel

def main():
    parser = argparse.ArgumentParser(description="News Headlines Aggregator")
    parser.add_argument("--source", help="Filter by source")
    parser.add_argument("--keyword", help="Filter by keyword")
    parser.add_argument("--date", help="Filter by date YYYY-MM-DD")
    parser.add_argument("--export", help="csv or excel")

    args = parser.parse_args()

    init_db()

    news1 = fetch_newsapi(args.keyword)
    news2 = scrape_bbc()

    all_news = news1 + news2
    filtered_news = filter_news(all_news, args.source, args.keyword, args.date)

    insert_news(filtered_news)

    print(f"{len(filtered_news)} articles saved to database")

    if args.export == "csv":
        export_csv()
    if args.export == "excel":
        export_excel()

if __name__ == "__main__":
    main()
