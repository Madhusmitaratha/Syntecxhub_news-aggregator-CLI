
import sqlite3

DB_NAME = "news.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS news(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT UNIQUE,
        source TEXT,
        date TEXT,
        url TEXT
    )
    """)

    conn.commit()
    conn.close()

def insert_news(news_list):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    for news in news_list:
        try:
            cur.execute(
                "INSERT INTO news(title,source,date,url) VALUES(?,?,?,?)",
                (news["title"], news["source"], news["date"], news["url"])
            )
        except sqlite3.IntegrityError:
            pass

    conn.commit()
    conn.close()
